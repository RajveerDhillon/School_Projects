I have replicated the Query Code from Lab 4 in lab 5. 
The application will start with the tasks you can choose from (Ranging 1 to 10 with description of the tasks).
The outputs will be as from lab 4 Sqlite Query Tables and the application uses 

Netbeans Version 8.2.


Choosing from 1 to 10 will show the output of the Query task.


Typing in quit will exit the application. 